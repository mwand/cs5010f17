// to compile and run this file, say
// javac <thisfilename>.java
// java Sum

class Sum {

    public static int sum (int[]A) {

        // find the sum of the values in an array

        int p = 0;
        int sofar = 0;

        // INVARIANT
        // p in [0,A.length)
        // 'sofar' is the sum of the elements of A in [0,p)
        // HALTING MEASURE: A.length - p
        // JUSTIFICATION: Invariant says p <= A.length, so is always
        // non-negative. At every call, p increases, so (A.length - p)
        // decreases. 

        while (p < A.length) {
            // add i to the looked-at region
            sofar = sofar + A[p];
            p++;
        }

        return sofar;
    }


    // tests for sum
    public static void main (String[] args) {
        int[] A = {};
        int[] B = {27};
        int[] C = {11,20};
        int[] D = {4,3,2,1};

        // tests using the PdpTestSuite

        // 10 is the timeout, in seconds
        PdpTestSuite tests = new PdpTestSuite(10);

        tests.addTestCase("sum of empty array should be 0",
                          () -> sum(A),
                          0);

        tests.addTestCase("sum of B should be 27",
                          () -> sum(B),
                          27);

        tests.addTestCase("sum of C should be 31",
                          () -> sum(C),
                          21);

        tests.addTestCase("sum of D should be 10",
                          () -> sum(C),
                          10);
        
        tests.runTests();
    }
}
