// to compile and run this file, say
// javac <thisfilename>.java
// java BinSearch

interface Tester {

    public boolean test (int n);

}

class LinSearch {

    public static int linear_search (Tester t, int[]A) {

        // find the index of the first element of A that passes
        // t.test, otherwise return -1

        int p = 0;

        // INVARIANT:
        // p in [0, A.length]
        // if j in in [0,i), then t.test(A[j]) is false

        // HALTING MEASURE: A.length - p
        // JUSTIFICATION: Invariant says p <= A.length, so is always
        // non-negative. At every call, i increases, so (A.length - i)
        // decreases.

        while (p != A.length) {
            if (t.test(A[p])) {
                // found it
                return p;
            }
            // no, keep looking
            p++;
        }
        // got to the end of the array without success
        return -1;
            
        
        // here's another way to write the loop that doesn't take
        // advantage of the ability to jump out of the middle of a loop.

        // while (i < A.length &&  !(t.test(A[i]))) { 
        //     // can we add i to the seen region?
        //     i++;
        // }
        // if (i == A.length) {
        //     // got to the end of the array
        //     return -1;
        // }
        // return i;

        
    }

    public static void main (String[] args) {
        int[] A = {2,4,9,16,25,36,49};
        int[] B = {2,2,3,3,8,9,10,10,12};
        int[] C = {};
        int[] D = {3,5,5,5,6,6,7,8,8,8,8};
        int[] E = {7,7,7,7};
        int[] F = {1,2,3,4};

        Tester t1 = new Is_square ();
        Tester t2 = new Is_even ();

        // try using PdpTestSuite
        // timeout of 10 seconds
        PdpTestSuite tests = new PdpTestSuite(10);

        tests.addTestCase("no squares in empty array",
                          () -> linear_search(t1,C),
                          -1);

        tests.addTestCase("no squares in D",
                          () -> linear_search(t1,D),
                          -1);

        tests.addTestCase("first square in A is 4",
                          () -> linear_search(t1,A),
                          1);

        tests.addTestCase("first square in B is 9",
                          () -> linear_search(t1,B),
                          5);

        tests.addTestCase("first square in B is 9 (better test)",
                          () -> B[linear_search(t1,B)],
                          9);

        tests.addTestCase("first even in A is 2",
                          () -> A[linear_search(t2,A)],
                          2);

        tests.addTestCase("no evens in C",
                          () -> linear_search(t2,C),
                          -1);

        tests.addTestCase("first even in F is 2",
                          () -> F[linear_search(t2,F)],
                          2);

        tests.runTests();

    }
}


class Is_square implements Tester {

    public boolean test (int n) {
        // is n a square number? 
        for (int i = 0; i <= n; i++) {
            if (n == i*i) {
                return true;
            }
        }
        return false;
    }

    // tests for Is_square
    public static void main (String[] args) {

        PdpTestSuite tests = new PdpTestSuite(10);
        Is_square o = new Is_square();

        tests.addTestCase("0 is a square",
                          () -> o.test(0),
                          true);

        tests.addTestCase("1 is a square",
                          () -> o.test(1),
                          true);

        tests.addTestCase("2 is not a square",
                          () -> o.test(2),
                          false);

        tests.addTestCase("64 might be a square, but it's too big for this tester",
                          () -> o.test(64),
                          false);

        tests.runTests();

    }

             
}
                
class Is_even implements Tester {

    public boolean test (int n) {
        return ((2 * (n / 2)) == n);
    }

    // tests for Is_even
    public static void main (String[] args) {

        PdpTestSuite tests = new PdpTestSuite(10);
        Is_even o = new Is_even();

        // test some even numbers
        for (int i = -2; i < 6; i = i+2) {
            int temp = i;
            tests.addTestCase(temp + " is even", ()->o.test(temp), true);
        }

                // test some odd numbers
        for (int i = -3; i < 6; i = i+2) {
            int temp = i;
            tests.addTestCase(temp + " is odd", ()->o.test(temp), false);
        }

        tests.runTests();

    }
}
