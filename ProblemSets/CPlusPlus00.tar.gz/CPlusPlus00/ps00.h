#ifndef PS00_H
#define PS00_H

#include <string>
#include <list>
#include "Module.h"

using namespace std;

extern bool isCircular (list<Module>* modules);

extern string bestMode (string m, list<Module>* modules);

extern list<string>* bestPlan (string m, list<Module>* modules);

#endif
