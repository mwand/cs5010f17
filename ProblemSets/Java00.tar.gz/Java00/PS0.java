// You can import more interface and class types here.

import java.util.List;

public abstract class PS0 {

    // canGetThere : String String ListOfFlight -> Boolean
    // GIVEN: the names of two airports, ap1 and ap2 (respectively),
    //     and a ListOfFlight that describes all of the flights a
    //     traveller is willing to consider taking
    // RETURNS: true if and only if it is possible to fly from the
    //     first airport (ap1) to the second airport (ap2) using
    //     only the given flights
    // EXAMPLES:
    //     canGetThere ( "06N", "JFK", panAmFlights )  =>  false
    //     canGetThere ( "LGA", "PDX", deltaFlights )  =>  true
    //
    // (For the definitions of panAmFlights and deltaFlights assumed
    // by those examples, see the FlightExamples class.)

    public static boolean canGetThere (String ap1,
                                       String ap2,
                                       List<Flight> flights) {
        // Your code goes here.
    }

    // fastestItinerary : String String ListOfFlight -> ListOfFlight
    // GIVEN: the names of two airports, ap1 and ap2 (respectively),
    //     and a ListOfFlight that describes all of the flights a
    //     traveller is willing to consider taking
    // WHERE: it is possible to fly from the first airport (ap1) to
    //     the second airport (ap2) using only the given flights
    // RETURNS: a list of flights that tells how to fly from the
    //     first airport (ap1) to the second airport (ap2) in the
    //     least possible time, using only the given flights
    // EXAMPLES:
    //     fastestItinerary ("LGA", "PDX", deltaFlights)
    // =>  [ makeFlight ("Delta 0121", "LGA", "MSP", 1100, 1409),
    //       makeFlight ("Delta 2163", "MSP", "PDX", 1500, 1902) ]

    public static List<Flight> fastestItinerary (String ap1, String ap2,
                                                 List<Flight> flights) {
        // Your code goes here.
    }

    // travelTime : String String ListOfFlight -> PosInt
    // GIVEN: the names of two airports, ap1 and ap2 (respectively),
    //     and a ListOfFlight that describes all of the flights a
    //     traveller is willing to consider taking
    // WHERE: it is possible to fly from the first airport (ap1) to
    //     the second airport (ap2) using only the given flights
    // RETURNS: the number of minutes it takes to fly from the first
    //     airport (ap1) to the second airport (ap2), including any
    //     layovers, by the fastest possible route that uses only
    //     the given flights
    // EXAMPLES:
    //     travelTime ( "LGA", "PDX", deltaFlights )  =>  482

    public static int travelTime (String ap1,
                                  String ap2,
                                  List<Flight> flights) {
        // Your code goes here.
    }

    // Your help methods go here.
}

